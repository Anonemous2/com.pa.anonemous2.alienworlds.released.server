model.biomes.push('alienred'),
model.biomes.push('SuperJovian'),
model.biomes.push('alienpurple'),
model.biomes.push('alientoxic')